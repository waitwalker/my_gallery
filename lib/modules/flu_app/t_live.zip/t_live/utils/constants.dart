const USERID_KEY = "UserId";
const DEFAULT_ROOM_IMAGE =
    "https://imgcache.qq.com/operation/dianshi/other/2.4c958e11852b2caa75da6c2726f9248108d6ec8a.png";
