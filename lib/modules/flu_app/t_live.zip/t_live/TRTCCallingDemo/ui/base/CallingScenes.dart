enum CallingScenes {
  VideoOneVOne, //一对一视频通话
  AudioOneVOne, //一对一语音通话
}
