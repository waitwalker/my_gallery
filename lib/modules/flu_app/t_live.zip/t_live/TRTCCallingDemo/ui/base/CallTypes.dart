enum CallTypes {
  Type_Call_Someone, //主动拨打某人
  Type_Being_Called, //作为用户被叫
}
