enum UserType {
  Anchor, //主播
  Administrator, //管理员
  Audience, //听众
}
enum UserStatus {
  Speaking, //讲话中
  Mute, //静音中
}
